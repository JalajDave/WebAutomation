# seleniumwithjava
This project is an automated testing framework for an online shopping app. It is built using Cucumber for BDD, the POM design pattern for better test maintenance, and TestNG as the test runner. The framework is designed to automate login realteed test scenarios such as  registration, login and logout

features  covered
-user registeration
-user login
-logout

--registeration data

| firstname        | lastname | email       | password  |

| demouser1  | ln1   | demouser1@gmail.com  | demo1@123|

| demouser2  | ln2      | demouser2@gmail.com    | demo2@123  |

--login data
| demouser@gmail.com         | demo@123 |





